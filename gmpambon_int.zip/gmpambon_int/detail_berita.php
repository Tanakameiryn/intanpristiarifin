<!DOCTYPE html>
<html>
<head>
    <title>Portal Berita</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0 ;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px;
        }

        .header {
            background-color: blueviolet;
            color: #fff;
            text-align: left;
            padding: 20px;
            padding-bottom: 10px;
            align-items: center;
        }

        .header .logo {
            margin-right: 20px;
        }

        .header .logo img {
            max-height: 60px;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
            background-color: blueviolet;
            flex: 1;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;        }

        nav li {
            margin-right: 20px;
        }

        nav li:last-child {
            margin-right: 0;
        }

        nav li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 5px 10px;
        }

        nav li a:hover {
            background-color: #555;
        }

        .admin-button {
            background-color: #333;
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .admin-button img {
            max-height: 30px;
            margin-right: 5px;
        }

        .admin-button a {
            display: flex;
            align-items: center;
            padding: 8px 16px;
            margin :10px;
            background-color: slateblue;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .admin-button a:hover {
            background-color: #555;
        }

        .content-container {
            display: flex;
            margin-top: 0;
            gap: 40px;
        }

        .landscape-container {
            flex: 1;
            max-width: 1000px;
        }

        .landscape-box {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            width: 100%;
        }

        .landscape-image {
            max-height: auto;
            overflow: hidden;
        }

        .landscape-image img {
            width: 100%;
            height: auto;
        }

        .landscape-desc {
            margin-top: 10px;
        }
        .news-container {
        align-items: center;
        flex: 1;
        padding-left: 10px;
        max-width: 400px;
        border: 1px solid #ccc;
        padding: 10px;
        margin-bottom: 20px;
        width: 100%;
        max-height: 1000px; /* Atur tinggi maksimum yang diinginkan */
        overflow-y: auto; /* Aktifkan scroll vertical jika isi melebihi tinggi maksimum */
    }

        .news-box {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            width: 100%;
            max-width: 300px;
        }

        .news-box img {
            max-width: 100%;
            height: 200px;
        }

        .news-box h3 {
            margin-top: 0;
            font-size: 18px;
            font-weight: bold;
        }

        .news-box p {
            margin: 5px 0;
            line-height: 1.5;
        }

        .news-box a {
            display: block;
            text-align: right;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }
        .news-detail img {
            width: 500px;
        }

    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <div class="logo">
                <img src="logo.jpg" alt="Logo">
            </div>
            <h1>Garuda Mas Pusura Ambon</h1>
        </div>
    </div>
        <div class="admin-button">
            <a href="admin/login.php">
                <img src="admin-logo.jpg" alt="Admin Logo">
            Admin</a>
        </div>
    <nav>
        <div class="container">
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="kontak_kami.php">Kontak Kami</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="content-container">
            <div class="landscape-container">
                <div class="landscape-box">
                    <?php
        // Periksa apakah ada parameter ID berita
        if (isset($_GET['id'])) {
            // Ambil ID berita dari URL query string
            $berita_id = $_GET['id'];

            // Buat koneksi ke database (sesuaikan dengan informasi koneksi Anda)
            $host = 'localhost';
            $username = 'root';
            $password = '';
            $database = 'gmpambon';
            $connection = new mysqli($host, $username, $password, $database);

            // Periksa apakah koneksi berhasil
            if ($connection->connect_error) {
                die("Koneksi database gagal: " . $connection->connect_error);
            }

            // Query untuk mengambil data berita berdasarkan ID
            $query = "SELECT * FROM data_berita WHERE id = $berita_id";

            // Eksekusi query
            $result = $connection->query($query);

            // Periksa apakah data berita dengan ID yang diberikan ada di database
            if ($result->num_rows > 0) {
                // Ambil data berita dari hasil query
                $row = $result->fetch_assoc();

                // Tampilkan detail berita
                echo '<div class="news-detail">';
                echo '<img src="admin/uploads/' . $row['image'] . '" alt="' . $row['title'] . '">';
                echo '<h2>' . $row['title'] . '</h2>';
                echo '<p>Penulis: ' . $row['category'] . '</p>';
                echo '<p>' . $row['content'] . '</p>';
                echo '</div>';
            } else {
                echo "Berita tidak ditemukan.";
            }

            // Tutup koneksi
            $connection->close();
        } else {
            echo "ID berita tidak valid.";
        }
        ?>
                </div>
            </div>
            <div class="news-container">
                <h2>Data Berita</h2>
                <?php
                // Buat koneksi ke database MySQL (ganti dengan informasi koneksi yang sesuai)
                $host = 'localhost'; // Contoh: 'localhost'
                $username = 'root'; // Contoh: 'root'
                $password = ''; // Ganti dengan kata sandi yang sesuai
                $database = 'gmpambon'; // Ganti dengan nama database Anda

                // Membuat koneksi
                $connection = new mysqli($host, $username, $password, $database);

                // Periksa apakah koneksi berhasil
                if ($connection->connect_error) {
                    die("Koneksi database gagal: " . $connection->connect_error);
                }

                // Query untuk mengambil data berita dari tabel "data_berita"
                $query = "SELECT * FROM data_berita";

                // Eksekusi query
                $result = $connection->query($query);

                // Cek apakah ada data berita yang ditemukan
                if ($result->num_rows > 0) {
                    // Tampilkan data berita dalam bentuk kotak
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="news-box">';
                        echo '<img src="admin/uploads/' . $row['image'] . '" alt="' . $row['title'] . '">';
                        echo '<h3>' . $row['title'] . '</h3>';
                        echo '<p>Penulis: ' . $row['category'] . '</p>';
                        echo '<p>' . substr($row['content'], 0, 100) . '...</p>';
                        echo '<a href="detail_berita.php?id=' . $row['id'] . '">Lihat Selengkapnya</a>';
                        echo '</div>';
                    }
                } else {
                    echo "Tidak ada data berita yang ditemukan.";
                }

                // Tutup koneksi
                $connection->close();
                ?>
            </div>
        </div>
    </div>
</body>
</html>
