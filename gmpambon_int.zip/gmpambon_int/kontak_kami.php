<!DOCTYPE html>
<html>
<head>
    <title>Portal Berita</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px;
        }

        .header {
            background-color: blueviolet;
            color: #fff;
            text-align: left;
            padding: 20px;
            padding-bottom: 10px;
            align-items: center;
        }

        .header .logo {
            margin-right: 20px;
        }

        .header .logo img {
            max-height: 60px;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
            background-color: blueviolet;
            flex: 1;
        }

        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav li {
            margin-right: 20px;
        }

        nav li:last-child {
            margin-right: 0;
        }

        nav li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 5px 10px;
        }

        nav li a:hover {
            background-color: #555;
        }

        .admin-button {
            background-color: #333;
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .admin-button img {
            max-height: 30px;
            margin-right: 5px;
        }

        .admin-button a {
            display: flex;
            align-items: center;
            padding: 8px 16px;
            margin: 10px;
            background-color: slateblue;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .admin-button a:hover {
            background-color: #555;
        }

        .content-container {
            display: flex;
            margin-top: 0;
            gap: 40px;
        }

        .landscape-container {
            flex: 1;
            max-width: 1000px;
        }

        .landscape-box {
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            width: 100%;
        }

        .landscape-image {
            max-height: auto;
            overflow: hidden;
        }

        .landscape-image img {
            width: 100%;
            height: auto;
        }

        .landscape-desc {
            margin-top: 10px;
        }

        .news-container {
            /* Tambahkan properti display: grid */
            display: grid;
            /* Tentukan jumlah kolom dalam grid */
            grid-template-columns: repeat(3, 1fr);
            /* Tentukan jarak antara kolom */
            grid-gap: 20px;
        }

        .news-box {
            border: 1px solid #ccc;
            padding: 20px;
            /* Tambahkan properti box-sizing: border-box */
            box-sizing: border-box;
            /* Tambahkan properti height: 100% */
            height: 100%;
        }

        .news-box img {
            max-width: 100%;
            height: auto;
        }

        .news-box h3 {
            margin-top: 0;
            font-size: 18px;
            font-weight: bold;
        }

        .news-box p {
            margin: 5px 0;
            line-height: 1.5;
        }

        .news-box a {
            display: block;
            text-align: right;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        /* Tambahkan CSS media query untuk ukuran layar yang lebih kecil */
        @media screen and (max-width: 767px) {
            .news-container {
                /* Ubah grid menjadi 2 kolom pada ukuran layar kecil */
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <div class="logo">
                <img src="logo.jpg" alt="Logo">
            </div>
            <h1>Garuda Mas Pusura Ambon</h1>
        </div>
    </div>
    <div class="admin-button">
        <a href="admin/login.php">
            <img src="admin-logo.jpg" alt="Admin Logo">
            Admin
        </a>
    </div>
    <nav>
        <div class="container">
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="kontak_kami.php">Kontak Kami</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="content-container">
            <div class="landscape-container">
                <!-- Konten landscape container -->
            </div>
            <div class="news-container">
                <?php
                // Buat koneksi ke database MySQL (ganti dengan informasi koneksi yang sesuai)
                $host = 'localhost'; // Contoh: 'localhost'
                $username = 'root'; // Contoh: 'root'
                $password = ''; // Ganti dengan kata sandi yang sesuai
                $database = 'gmpambon'; // Ganti dengan nama database Anda

                // Membuat koneksi
                $connection = new mysqli($host, $username, $password, $database);

                // Periksa apakah koneksi berhasil
                if ($connection->connect_error) {
                    die("Koneksi database gagal: " . $connection->connect_error);
                }

                // Query untuk mengambil data kontak dari tabel "data_kontak"
                $query = "SELECT * FROM data_kontak";

                // Eksekusi query
                $result = $connection->query($query);

                // Cek apakah ada data kontak yang ditemukan
                if ($result->num_rows > 0) {
                    // Tampilkan data kontak dalam bentuk kartu
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="news-box">';
                        echo '<img src="admin/uploads/' . $row['gambar'] . '" alt="' . $row['nama'] . '">';
                        echo '<h3>' . $row['nama'] . '</h3>';
                        echo '<p>No Kontak: ' . $row['no_kontak'] . '</p>';
                        echo '<p>Facebook: ' . $row['facebook'] . '</p>';
                        echo '<p>Instagram: ' . $row['instagram'] . '</p>';
                        echo '<p>Email: ' . $row['email'] . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo "Tidak ada data kontak yang ditemukan.";
                }

                // Tutup koneksi
                $connection->close();
                ?>
            </div>
        </div>
    </div>
</body>
</html>
