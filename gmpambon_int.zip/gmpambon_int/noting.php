<?php
        // Periksa apakah ada parameter ID berita
        if (isset($_GET['id'])) {
            // Ambil ID berita dari URL query string
            $berita_id = $_GET['id'];

            // Buat koneksi ke database (sesuaikan dengan informasi koneksi Anda)
            $host = 'localhost';
            $username = 'root';
            $password = '';
            $database = 'gmpambon';
            $connection = new mysqli($host, $username, $password, $database);

            // Periksa apakah koneksi berhasil
            if ($connection->connect_error) {
                die("Koneksi database gagal: " . $connection->connect_error);
            }

            // Query untuk mengambil data berita berdasarkan ID
            $query = "SELECT * FROM data_berita WHERE id = $berita_id";

            // Eksekusi query
            $result = $connection->query($query);

            // Periksa apakah data berita dengan ID yang diberikan ada di database
            if ($result->num_rows > 0) {
                // Ambil data berita dari hasil query
                $row = $result->fetch_assoc();

                // Tampilkan detail berita
                echo '<div class="news-detail">';
                echo '<img src="admin/uploads/' . $row['image'] . '" alt="' . $row['title'] . '">';
                echo '<h2>' . $row['title'] . '</h2>';
                echo '<p>Penulis: ' . $row['category'] . '</p>';
                echo '<p>' . $row['content'] . '</p>';
                echo '</div>';
            } else {
                echo "Berita tidak ditemukan.";
            }

            // Tutup koneksi
            $connection->close();
        } else {
            echo "ID berita tidak valid.";
        }
        ?>


        <div class="news-container">
            <?php
            // Buat koneksi ke database MySQL (ganti dengan informasi koneksi yang sesuai)
            $host = 'localhost'; // Contoh: 'localhost'
            $username = 'root'; // Contoh: 'root'
            $password = ''; // Ganti dengan kata sandi yang sesuai
            $database = 'gmpambon'; // Ganti dengan nama database Anda

            // Membuat koneksi
            $connection = new mysqli($host, $username, $password, $database);

            // Periksa apakah koneksi berhasil
            if ($connection->connect_error) {
                die("Koneksi database gagal: " . $connection->connect_error);
            }

            // Query untuk mengambil data kontak dari tabel "data_berita"
            $query = "SELECT * FROM data_kontak";

            // Eksekusi query
            $result = $connection->query($query);

            // Cek apakah ada data kontak yang ditemukan
            if ($result->num_rows > 0) {
                // Tampilkan data kontak dalam bentuk kartu
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="contact-card">';
                    echo '<img src="admin/uploads/' . $row['gambar'] . '" alt="' . $row['nama'] . '">';
                    echo '<h3>' . $row['nama'] . '</h3>';
                    echo '<p>No Kontak: ' . $row['no_kontak'] . '</p>';
                    echo '<p>Facebook: ' . $row['facebook'] . '</p>';
                    echo '<p>Instagram: ' . $row['instagram'] . '</p>';
                    echo '<p>Email: ' . $row['email'] . '</p>';
                    echo '</div>';
                }
            } else {
                echo "Tidak ada data kontak yang ditemukan.";
            }

            // Tutup koneksi
            $connection->close();
            ?>
        </div>