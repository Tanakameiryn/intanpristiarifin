<!DOCTYPE html>
<html>
<head>
    <title>Garuda Mas Pusura - Kontak Kami</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style type="text/css">
        .gambar-berita {
            width: 300px;
            height: 200px;
            object-fit: cover; /* Agar gambar tetap proporsional */
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <h1>Halaman Admin</h1>
            <div class="admin-menu">
                <a href="data_berita.php">Berita</a>
                <a href="post_berita.php">Post Berita</a>
                <a href="kontak_kami_admin.php">Data Kontak</a>
                <a href="../index.php">Keluar</a>
            </div>
        </div>
        <div class="admin-content">
            <div class="landscape-box">
            <h2>Kontak Kami</h2>
            <form action="proses_kontak_kami_admin.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nama:</label>
                    <input type="text" name="nama" required>
                </div>
                <div class="form-group">
                    <label>Gambar:</label>
                    <input type="file" name="gambar" required>
                </div>
                <div class="form-group">
                    <label>Nomor Telepon:</label>
                    <input type="text" name="nomor_telepon" required>
                </div>
                <div class="form-group">
                    <label>Facebook:</label>
                    <input type="text" name="facebook" required>
                </div>
                <div class="form-group">
                    <label>Instagram:</label>
                    <input type="text" name="instagram" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="text" name="email" required>
                </div>
                <div class="form-group">
                    <input type="submit" value="Simpan">
                </div>
            </div>
            </form>
          <?php
            // Kode untuk menampilkan daftar data kontak dari database
            require_once('koneksi.php');

            // Fungsi untuk menghapus data kontak berdasarkan ID
            function hapusKontak($id) {
                global $connection;
                $sqlDelete = "DELETE FROM data_kontak WHERE id = '$id'";
                if ($connection->query($sqlDelete) === TRUE) {
                    header('Location: kontak_kami_admin.php');
                    exit;
                } else {
                    echo "Error saat menghapus data kontak: " . $connection->error;
                }
            }

            // Cek apakah parameter "delete" ada di URL
            if (isset($_GET["delete"])) {
                $idToDelete = $_GET["delete"];
                hapusKontak($idToDelete);
            }

            // Query untuk mendapatkan data kontak dari tabel data_kontak
            $sql = "SELECT * FROM data_kontak";
            $result = $connection->query($sql);

            // Memeriksa apakah terdapat data kontak
            if ($result->num_rows > 0) {
                // Menampilkan data kontak dalam tabel
                echo '<table>';
                echo '<tr>';
                echo '<th>Nama</th>';
                echo '<th>Gambar</th>';
                echo '<th>Nomor Telepon</th>';
                echo '<th>Facebook</th>';
                echo '<th>Instagram</th>';
                echo '<th>Email</th>';
                echo '<th>Aksi</th>';
                echo '</tr>';
                
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['nama'] . '</td>';
                    echo '<td><img class="gambar-berita" src="uploads/' . $row['gambar'] . '" alt="' . $row['nama'] . '"></td>';
                    echo '<td>' . $row['no_kontak'] . '</td>';
                    echo '<td>' . $row['facebook'] . '</td>';
                    echo '<td>' . $row['instagram'] . '</td>';
                    echo '<td>' . $row['email'] . '</td>';
                    echo '<td><a href="?delete=' . $row['id'] . '" onclick="return confirm(\'Apakah Anda yakin ingin menghapus data kontak ini?\')">Hapus</a></td>';
                    echo '</tr>';
                }
                
                echo '</table>';
            } else {
                echo "Tidak ada data kontak.";
            }

            // Menutup koneksi
            $connection->close();
            ?>
    </div>
    <script>
        // Add JavaScript to remove the URL history entry for data_berita.php when the "Keluar" link is clicked
        const logoutLink = document.querySelector('a[href="../index.php"]');
        if (logoutLink) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                // Redirect to logout.php
                window.location.href = '../index.php';
                // Remove the history entry for data_berita.php
                history.replaceState(null, null, 'login.php');
            });
        }
    </script>
</body>
</html>
