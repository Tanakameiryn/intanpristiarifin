<?php
// Pastikan file ini berada di direktori yang sama dengan file koneksi.php
require_once('koneksi.php');

// Memeriksa apakah form telah di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menyimpan data yang diterima dari form ke dalam variabel
    $nama = $_POST['nama'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $facebook = $_POST['facebook'];
    $instagram = $_POST['instagram'];
    $email = $_POST['email'];

    // Menggunakan fungsi mysqli_real_escape_string untuk membersihkan data sebelum disimpan ke database
    $nama = $connection->real_escape_string($nama);
    $nomor_telepon = $connection->real_escape_string($nomor_telepon);
    $facebook = $connection->real_escape_string($facebook);
    $instagram = $connection->real_escape_string($instagram);
    $email = $connection->real_escape_string($email);

    // Menyimpan gambar ke folder uploads (pastikan folder uploads sudah ada dan memiliki hak akses tulis)
    $gambar = $_FILES['gambar']['name'];
    $tmp_name = $_FILES['gambar']['tmp_name'];
    move_uploaded_file($tmp_name, "uploads/" . $gambar);

    // Query untuk menyimpan data ke tabel data_kontak
    $query = "INSERT INTO data_kontak (nama, gambar, no_kontak, facebook, instagram, email) VALUES ('$nama', '$gambar', '$nomor_telepon', '$facebook', '$instagram', '$email')";

    // Eksekusi query
    if ($connection->query($query) === TRUE) {
        // Redirect ke halaman data kontak setelah berhasil menyimpan data
        header('Location: kontak_kami_admin.php');
        exit;
    } else {
        echo "Error saat menyimpan data: " . $connection->error;
    }
}

// Menutup koneksi
$connection->close();
?>
