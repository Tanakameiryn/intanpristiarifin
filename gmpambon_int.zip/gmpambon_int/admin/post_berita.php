<?php
// Membuat koneksi dengan database
$host = "localhost"; // Ganti dengan host database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "gmpambon"; // Ganti dengan nama database Anda
$conn = new mysqli($host, $username, $password, $dbname);

// Memeriksa apakah terjadi error pada koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Memproses form submission saat tombol "Post Berita" ditekan
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $post_time = $_POST["post_time"];
    $title = $_POST["title"];
    $content = $_POST["content"];
    $category = $_POST["category"];
    $image = $_FILES["image"]["name"];
    $image_temp = $_FILES["image"]["tmp_name"];

    // Upload gambar ke folder 'uploads'
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image);
    move_uploaded_file($image_temp, $target_file);

    // Query untuk menyimpan data berita ke database
    $sqlInsert = "INSERT INTO data_berita (title, content, category, image, posting_time) 
                  VALUES ('$title', '$content', '$category', '$image', '$post_time')";

    if ($conn->query($sqlInsert) === TRUE) {
        // Redirect kembali ke halaman data_berita.php setelah berhasil menyimpan berita
        header('Location: data_berita.php');
        exit;
    } else {
        // Jika terjadi error saat menyimpan data
        echo "Error saat menyimpan berita: " . $conn->error;
    }
}

// Menutup koneksi database
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Post Berita</title>
    <style>
        body {
            background-color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh; 
        }

        .admin-container {
            display: flex;
            height: 100%; 
        }

        .admin-sidebar {
            flex: 1;
            max-width: 200px;
            background-color: #007bff; 
            color: #ffffff;
            padding: 20px;
            border-radius: 5px 0 0 5px;
            display: flex;
            height: 100%;
            flex-direction: column;
        }

        .admin-menu {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .admin-menu a {
            color: #ffffff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 3px;
            text-align: center;
        }

        .admin-menu a:hover {
            background-color: #0069d9; 
        }

        .admin-content {
            flex: 2;
            padding: 20px;
            height: 100%; 
            overflow-y: auto; /* Menampilkan scrollbar jika konten terlalu panjang */
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        .admin-content h2 {
            margin-bottom: 10px;
        }

        /* Set ukuran gambar berita */
        .gambar-berita {
            width: 150px;
            height: 100px;
            object-fit: cover;
        }

        .post-container {
            padding: 20px;
            background-color: #ffffff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .post-form {
            margin-top: 20px;
        }

        .post-form label {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        .post-form input[type="text"],
        .post-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
            border: 1px solid #ccc;
        }

        .post-form textarea {
            height: 200px;
        }

        .post-form input[type="submit"] {
            background-color: #007bff;
            color: #ffffff;
            padding: 10px;
            border: none;
            cursor: pointer;
        }

        .post-form input[type="submit"]:hover {
            background-color: #0069d9;
        }

        .success-message {
            background-color: #007bff; 
            color: #ffffff;
            padding: 10px;
            border-radius: 3px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <h1>Halaman Admin</h1>
            <div class="admin-menu">
                <a href="data_berita.php">Berita</a>
                <a href="post_berita.php">Post Berita</a>
                <a href="kontak_kami_admin.php">Data Kontak</a>
                <a href="../index.php">Keluar</a>
            </div>
        </div>
        <div class="admin-content">
            <h1>Post Berita</h1>
            <div class="post-container">
                <a href="halaman_admin.php" style="float: right; margin-top: 10px;">Kembali</a>
                <form class="post-form" method="POST" action="" enctype="multipart/form-data">
                    <label for="post_time">Waktu Posting:</label>
                    <input type="datetime-local" name="post_time" required>

                    <label for="title">Judul:</label>
                    <input type="text" name="title" required>

                    <label for="content">Isi Berita:</label>
                    <textarea name="content" required></textarea>

                    <label for="category">Penulis:</label>
                    <input type="text" name="category" required>

                    <label for="image">Gambar:</label>
                    <input type="file" name="image" accept="image/*">

                    <input type="submit" name="submit" value="Post Berita">
                </form>
            </div>
        </div>
    </div>
    <script>
        // Add JavaScript to remove the URL history entry for data_berita.php when the "Keluar" link is clicked
        const logoutLink = document.querySelector('a[href="../index.php"]');
        if (logoutLink) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                // Redirect to logout.php
                window.location.href = '../index.php';
                // Remove the history entry for data_berita.php
                history.replaceState(null, null, 'login.php');
            });
        }
    </script>
</body>
</html>
