<?php
// Membuat koneksi dengan database
$host = "localhost"; // Ganti dengan host database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "gmpambon"; // Ganti dengan nama database Anda
$conn = new mysqli($host, $username, $password, $dbname);

// Memeriksa apakah terjadi error pada koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Periksa apakah ada parameter ID berita
if (isset($_GET['id'])) {
    $berita_id = $_GET['id'];
    $sql = "SELECT * FROM data_berita WHERE id = '$berita_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Berita tidak ditemukan.";
    }
} else {
    echo "ID berita tidak valid.";
}

$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Berita - Garuda Mas Pusura</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <h1>Halaman Admin</h1>
            <div class="admin-menu">
                <a href="data_berita.php">Berita</a>
                <a href="post_berita.php">Post Berita</a>
                <a href="kontak_kami_admin.php">Data Kontak</a>
                <a href="../index.php">Keluar</a>
            </div>
        </div>
         <div class="admin-content">
            <h2>Edit Berita</h2>
            <a href="data_berita.php" style="float: right; margin-top: 10px;">Batal</a>
            <form action="proses_edit_berita.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label>Judul:</label>
                    <input type="text" name="judul" value="<?php echo $row['title']; ?>">
                </div>
                <div class="form-group">
                    <label>Konten:</label>
                    <textarea name="konten"><?php echo $row['content']; ?></textarea>
                </div>
                <div class="form-group">
                    <label>Penulis:</label>
                    <input type="text" name="penulis" value="<?php echo $row['category']; ?>">
                </div>

                <div class="form-group">
                    <input type="submit" value="Simpan">
                </div>
            </form>
        </div>
    </div>
    <script>
        // Add JavaScript to remove the URL history entry for data_berita.php when the "Keluar" link is clicked
        const logoutLink = document.querySelector('a[href="../index.php"]');
        if (logoutLink) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                // Redirect to logout.php
                window.location.href = '../index.php';
                // Remove the history entry for data_berita.php
                history.replaceState(null, null, 'login.php');
            });
        }
    </script>
</body>
</html>
