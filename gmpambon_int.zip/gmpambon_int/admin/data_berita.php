<!DOCTYPE html>
<html>
<head>
    <title>Garuda Mas Pusura</title>
      <link rel="stylesheet" type="text/css" href="style.css">
      <style type="text/css">
      </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <h1>Halaman Admin</h1>
            <div class="admin-menu">
                <a href="data_berita.php">Berita</a>
                <a href="post_berita.php">Post Berita</a>
                <a href="kontak_kami_admin.php">Data Kontak</a>
                <a href="../index.php">Keluar</a>
            </div>
        </div>
        <div class="admin-content">
            <h2>Data Berita</h2>
            <table>
                <tr>
                    <th>Judul</th>
                    <th>Konten</th>
                    <th>Penulis</th>
                    <th>Gambar</th>
                    <th>Waktu Posting</th>
                    <th>Aksi</th>
                </tr>
                <?php

                // Membuat koneksi dengan database
                $host = "localhost"; // Ganti dengan host database Anda
                $username = "root"; // Ganti dengan username database Anda
                $password = ""; // Ganti dengan password database Anda
                $dbname = "gmpambon"; // Ganti dengan nama database Anda
                $conn = new mysqli($host, $username, $password, $dbname);

                // Memeriksa apakah terjadi error pada koneksi
                if ($conn->connect_error) {
                    die("Koneksi database gagal: " . $conn->connect_error);
                }

                // Memproses penghapusan berita jika parameter "delete" ada di URL
                if (isset($_GET["delete"])) {
                    // Mendapatkan ID berita yang akan dihapus dari parameter "delete"
                    $idToDelete = $_GET["delete"];

                    // Query untuk menghapus data berita dari database berdasarkan ID
                    $sqlDelete = "DELETE FROM data_berita WHERE id = '$idToDelete'";

                    // Menjalankan query penghapusan
                    if ($conn->query($sqlDelete) === TRUE) {
                        // Redirect kembali ke halaman data_berita.php setelah berhasil menghapus berita
                        header('Location: data_berita.php');
                        exit;
                    } else {
                        // Jika terjadi error saat menghapus data
                        echo "Error saat menghapus berita: " . $conn->error;
                    }
                }

                // Query untuk mendapatkan data berita dari database
                $sql = "SELECT * FROM data_berita";
                $result = $conn->query($sql);

                // Memeriksa apakah terdapat data berita
                if ($result->num_rows > 0) {
                    // Menampilkan data berita dalam tabel
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['title'] . "</td>";
                        echo "<td>" . truncateContent($row['content']) . "</td>";
                        echo "<td>" . $row['category'] . "</td>";
                        echo "<td><img class='gambar-berita' src='uploads/" . $row['image'] . "' alt='Gambar Berita'></td>";
                        echo "<td class='post-info'>" . $row['posting_time'] . "</td>";
                        echo "<td><a href='edit_berita.php?id=" . $row['id'] . "'>Edit</a> | <a href='data_berita.php?delete=" . $row['id'] . "' onclick='return confirm(\"Apakah Anda yakin ingin menghapus berita ini?\")'>Hapus</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>Tidak ada data berita.</td></tr>";
                }

                // Menutup koneksi database
                $conn->close();

                // Fungsi untuk memotong konten berita
                function truncateContent($content, $length = 100) {
                    if (strlen($content) > $length) {
                        $content = substr($content, 0, $length) . "...";
                    }
                    return $content;
                }
                ?>
            </table>
        </div>
    </div>
    <script>
        // Add JavaScript to remove the URL history entry for data_berita.php when the "Keluar" link is clicked
        const logoutLink = document.querySelector('a[href="../index.php"]');
        if (logoutLink) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                // Redirect to logout.php
                window.location.href = '../index.php';
                // Remove the history entry for data_berita.php
                history.replaceState(null, null, 'login.php');
            });
        }
    </script>
</body>
</html>
