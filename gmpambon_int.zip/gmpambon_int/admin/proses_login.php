<?php
// Koneksi ke database
$host = 'localhost'; // Ganti dengan host database Anda
$username = 'root'; // Ganti dengan username database Anda
$password = ''; // Ganti dengan kata sandi database Anda
$database = 'gmpambon'; // Ganti dengan nama database Anda

$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Memproses data login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query SQL untuk mencari admin berdasarkan username
    $query = "SELECT * FROM data_admin WHERE username = '$username'";
    $result = mysqli_query($connection, $query);

    if (mysqli_num_rows($result) == 1) {
        // Admin ditemukan, cek password
        $row = mysqli_fetch_assoc($result);
        if ($row["password"] == $password) {
            // Login berhasil, alihkan ke halaman admin
            header('Location: halaman_admin.php');
            exit; // Hentikan eksekusi script
        } else {
            // Password salah, kembali ke halaman login dengan pesan kesalahan
            header('Location: login.php?error=Password salah. Silakan coba lagi.');
            exit;
        }
    } else {
        // Username tidak ditemukan, kembali ke halaman login dengan pesan kesalahan
        header('Location: login.php?error=Username tidak ditemukan. Silakan coba lagi.');
        exit;
    }

    mysqli_close($connection);
}
?>
