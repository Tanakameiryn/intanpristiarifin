<?php
// Membuat koneksi dengan database
$host = "localhost"; // Ganti dengan host database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "gmpambon"; // Ganti dengan nama database Anda
$conn = new mysqli($host, $username, $password, $dbname);

// Memeriksa apakah terjadi error pada koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Periksa apakah ada gambar baru yang diunggah
if (!empty($_FILES['gambar_baru']['tmp_name'])) {
    // Mendapatkan informasi gambar baru
    $gambarBaru = $_FILES['gambar_baru'];
    $namaFileBaru = basename($gambarBaru['name']);
    $lokasiFileBaru = "uploads/" . $namaFileBaru;

    // Memindahkan gambar baru ke lokasi yang diinginkan
    if (move_uploaded_file($gambarBaru['tmp_name'], $lokasiFileBaru)) {
        // Memperbarui data gambar dalam database
        $id = $_POST['id'];
        $sqlUpdateGambar = "UPDATE data_berita SET image = '$lokasiFileBaru' WHERE id = '$id'";
        $resultUpdate = $conn->query($sqlUpdateGambar);

        if (!$resultUpdate) {
            echo "Gagal memperbarui gambar: " . $conn->error;
        }
    } else {
        echo "Gagal mengunggah gambar baru.";
    }
}

// Memeriksa apakah ada data yang dikirimkan melalui form
if (isset($_POST['id']) && isset($_POST['judul']) && isset($_POST['konten']) && isset($_POST['penulis'])) {
    // Mengambil data dari form
    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $konten = $_POST['konten'];
    $penulis = $_POST['penulis'];

    // Query untuk melakukan update data berita berdasarkan ID
    $sql = "UPDATE data_berita SET title='$judul', content='$konten', category='$penulis' WHERE id='$id'";

    // Menjalankan query update
    if ($conn->query($sql) === TRUE) {
        // Redirect kembali ke halaman data_berita.php setelah berhasil mengedit berita
        header('Location: data_berita.php');
        exit;
    } else {
        // Jika terjadi error saat melakukan update
        echo "Error saat mengedit berita: " . $conn->error;
    }
} else {
    echo "Data tidak lengkap. Harap lengkapi semua field.";
}

// Menutup koneksi database
$conn->close();
?>
