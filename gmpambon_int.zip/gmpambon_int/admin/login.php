<!DOCTYPE html>
<html>
<head>
    <title>Form Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin : 10px;
            width: 500px;
            height: 500px;
        }

        .container h2 {
            margin-bottom: 20px;
            text-align: center;
             padding: 20px;
            margin : 10px;
        }

        .form-group {
            margin-bottom: 15px;
             padding: 20px;
            margin : 10px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .back-to-home {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            color: #007bff;
        }

        .back-to-home:hover {
            text-decoration: underline;
        }
         <style>
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
    </style>
</head>
<body>
    <div class="container">
        <h2>Form Login</h2>
        <form action="proses_login.php" method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="error-message">
            <?php
                if (isset($_GET['error'])) {
                echo '<p class="error-message">' . $_GET['error'] . '</p>';
                }
            ?>
            </div>
            <div class="form-group">
                <input type="submit" value="Login">
            </div>
        </form>
        <a class="back-to-home" href="../index.php">Kembali ke Beranda</a>
    </div>
</body>
</html>
