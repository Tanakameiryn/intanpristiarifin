<!DOCTYPE html>
<html>
<head>
    <title>Halaman Admin</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="admin-container">
        <div class="admin-sidebar">
            <h1>Halaman Admin</h1>
            <div class="admin-menu">
                <a href="data_berita.php">Berita</a>
                <a href="post_berita.php">Post Berita</a>
                <a href="kontak_kami_admin.php">Data Kontak</a>
                <a href="index.php">Keluar</a>
            </div>
        </div>
        <div class="admin-content">
            <h2>Selamat datang, Admin!</h2>
            <p>Ini adalah halaman admin</p>
            <p>Silakan pilih menu di samping untuk melanjutkan.</p>
        </div>
    </div>
    <script>
        // Add JavaScript to remove the URL history entry for data_berita.php when the "Keluar" link is clicked
        const logoutLink = document.querySelector('a[href="../index.php"]');
        if (logoutLink) {
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                // Redirect to logout.php
                window.location.href = '../index.php';
                // Remove the history entry for data_berita.php
                history.replaceState(null, null, 'login.php');
            });
        }
    </script>
</body>
</html>
